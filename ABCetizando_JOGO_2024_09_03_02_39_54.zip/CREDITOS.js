function telaCredito(){
  background(telacredito);
}