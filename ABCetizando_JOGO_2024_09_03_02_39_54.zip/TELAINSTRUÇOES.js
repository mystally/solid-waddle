function telaInstrucao(){
  background(telainst);
}