function telaJogo(){
  background(teladejogo)
}