var menu;
var teladejogo; 
var tela = 0; // contador incremento de telas
var telainst; 
var telacredito; 

function preload(){
  menu = loadImage('MENU.png');
  teladejogo = loadImage('TELAJOGO.png');
  telainst = loadImage('INSTRUÇOES.png');
  telacredito = loadImage('CREDITOS.png');
} // função do p5js reference para carregar imagens na tela


function setup() {
  createCanvas(500, 500); // define o tamanho da tela
}

function draw(){
  
    if(tela==0){ /// tela0 = tela de menu
        background(menu); // plano de fundo
      
        circle(mouseX, mouseY, 10); // bolinha mouse
        
        
    if(mouseX>=150 && mouseY>=140 && mouseX<= 345 && mouseY<=175){
        noFill();
        stroke(199);
        rect(145, 135, 210, 40, 10); // botao jogar 
        
    
     if(mouseIsPressed){
        tela = 1; // se o botao for pressionado ira para a tela1 = tela de jogo
            }
         }
      
        circle(mouseX, mouseY, 10); // bolinha do mouse
            
    if(mouseX>=70 && mouseY>=215 && mouseX<=440 && mouseY<=250){
        noFill();
        stroke(199);
        rect(65,210,380,45,10);
      // botao instruçoes
        
    
    if(mouseIsPressed){
        tela = 2; // se o botao for pressionado ira para a tela2 = tela de instruçoes
          }
        }
      
      circle(mouseX, mouseY, 10); // bolinha do mouse
      
    if(mouseX>=100 && mouseY>=310 && mouseX<= 400 && mouseY<=340){
      noFill();
      stroke(199);
      rect(100, 303, 298, 45, 10);
      // botao creditos
      
      
    if(mouseIsPressed){
        tela = 3; 
      // se o botao for pressionado ira para a tela3 = tela creditos
      }
    }
        circle(mouseX, mouseY, 10); // bolinha mouse
    }
    else if(tela == 1){
        telaJogo(); // backgroud dentro da tela de jogo
  
        circle(mouseX, mouseY, 10); // bolinha mouse
       
    if(mouseX>=180 && mouseY>=85 && mouseX<=320 && mouseY<=125){
        noFill();
        stroke(199);
        rect(180,80,140,45,10);
      // criando botao voltar dentro da tela de jogo
      
        
    if(mouseIsPressed){
        tela = 0;
      // se o botao dentro da tela de jogo for pressionado ira para a tela 0 = tela de menu
    
        }
      }
    }
    else if(tela == 2){
        telaInstrucao(); //background dentro da tela de inst
        
        circle(mouseX, mouseY, 10); // bolinha mouse
      
    if(mouseX>=25 && mouseY>=440 && mouseX<=170 && mouseY<=470){
        noFill();
        stroke(199);
        rect(27,432,145,47,10);
    // botao de voltar dentro da tela de instruçoes
      
    if(mouseIsPressed){
        tela = 0;
      // se o botao dentro da tela de instruçoes for pressionado ira para a tela 0 = tela de menu
      
      }
    }
  } 
    else if(tela == 3){
      telaCredito(); // background dentro da tela credito
 
      circle(mouseX, mouseY, 10); // bolinha mouse
        
    if(mouseX>=335 && mouseY>=440 && mouseX<=480 && mouseY<=480){
      noFill();
      stroke(199);
      rect(330, 432, 155, 45, 10);
      // botao dentro da tela de creditos para voltar pra tela de menu
    
      
    if(mouseIsPressed){
        tela = 0;
      // se o botao dentro da tela de creditos for pressionado ira para a tela 0 = tela de menu
  
      }
    }
  }
}